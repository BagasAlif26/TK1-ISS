def generate_key(nim, length):
    key = nim
    while len(key) < length:
        key += nim
    return key[:length]

def encrypt(plaintext, key):
    ciphertext = ''
    for i in range(len(plaintext)):
        char = plaintext[i]
        key_char = key[i]
        encrypted_char = chr((ord(char) + ord(key_char)) % 256)
        ciphertext += encrypted_char
    return ciphertext

def decrypt(ciphertext, key):
    plaintext = ''
    for i in range(len(ciphertext)):
        char = ciphertext[i]
        key_char = key[i]
        decrypted_char = chr((ord(char) - ord(key_char)) % 256)
        plaintext += decrypted_char
    return plaintext

def main():
    print("\n Selamat Datang di TIM 5 ISS"
          "\n (づ｡◕‿‿◕｡)づ")

    address = input(
                    "\n Masukkan alamat gerai Kopi Kenangan terdekat kamu: ")
    nim = input(" Masukkan NIM kamu sebagai kunci: ")

    key = generate_key(nim, len(address))

    ciphertext = encrypt(address, key)
    print(
          "\n (>‿◠)✌"
          "\nPesan kamu telah terenkripsi:", ciphertext)

    # Inisialisasi variabel untuk menghitung percobaan
    attempts = 0

    while attempts < 3:
        input_nim = input("\n Apakah kamu ingin dekripsi pesan atau ingin keluar? "
                          "\n ~(˘▾˘~)"
                          "\n Tekan (E) untuk keluar"
                          "\n Tekan (D) untuk Dekripsi Pesan)"
                          "\n : ")

        if input_nim.upper() == 'E':
            print("\nProgram selesai "
                  "\n(👍≖‿‿≖)👍 👍(≖‿‿≖👍)")
            break
        elif input_nim.upper() == 'D':
            input_nim_decrypt = input("\nMasukkan NIM kamu untuk dekripsi: ")
            if input_nim_decrypt == nim:
                decrypted_address = decrypt(ciphertext, key)
                print("\n ≧◠‿◠≦✌"
                      "\nPesan terdekripsi:", decrypted_address)
                break
            else:
                print("\nNIM yang kamu dimasukkan salah!"
                      "\nDiisi dengan benar ya..."
                      "\nPercobaan ke-", attempts + 1)
                attempts += 1
        else:
            print("\n ~~~~~~~~~~~~"
                  "\n Input yang kamu masukan tidak valid. Silakan masukkan (E) atau (D) (◡̀_◡҂́)ᕤ")

    if attempts == 3:
        print("\n"
              "\nKamu sudah melebihi batas percobaan. 💪(◡̀_◡́҂)"
              "\nProgram berhenti.")

if __name__ == "__main__":
    main()
